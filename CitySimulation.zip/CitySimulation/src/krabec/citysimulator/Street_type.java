package krabec.citysimulator;

import java.io.Serializable;

public enum Street_type implements Serializable{
	major,
	minor,
	lot_border
}
