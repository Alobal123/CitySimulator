package krabec.citysimulator.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import krabec.citysimulator.Lut;
import krabec.citysimulator.Mapping;
import krabec.citysimulator.Valuation;
import krabec.citysimulator.Valuation_Types;
import javax.swing.JLabel;
import java.awt.GridLayout;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JComboBox;

public class Lut_edit extends JDialog {

	
	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();

	Lut lut;
	Lut_panel parent;
	JPanel panel;
	private JTextField textField;
	private JSpinner textField_1;

	
	/**
	 * Create the dialog.
	 */
	public Lut_edit(Lut lut,Lut_panel parent) {
		this.setTitle("Editing "+ lut.getName());
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.lut = lut;
		this.parent = parent;
		Lut_edit thiswindow = this;
		setBounds(100, 100, 450, 600);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JPanel panel = new JPanel();
			contentPanel.add(panel, BorderLayout.NORTH);
			panel.setLayout(new GridLayout(0, 2, 0, 0));
			{
				JLabel lblNewLabel = new JLabel("Name");
				panel.add(lblNewLabel);
			}
			{
				textField = new JTextField();
				panel.add(textField);
				textField.setText(lut.getName());
				textField.setColumns(10);
				textField.getDocument().addDocumentListener(new DocumentListener() {
					  public void changedUpdate(DocumentEvent e) {
					    lut.setName(textField.getText());
					  }
					  public void removeUpdate(DocumentEvent e) {
						  lut.setName(textField.getText());
					  }
					  public void insertUpdate(DocumentEvent e) {
						  lut.setName(textField.getText());
					  }
					   
				});
			}
			{
				JLabel lblNewLabel_1 = new JLabel("Residents density");
				panel.add(lblNewLabel_1);
			}
			{
				textField_1 = new JSpinner();
				
				textField_1.setModel(new SpinnerNumberModel(0.5, 0.5, 5.0, 0.5));
				textField_1.setValue(lut.residents);
				panel.add(textField_1);
				{
					JLabel lblNewLabel_5 = new JLabel("");
					panel.add(lblNewLabel_5);
				}
				{
					JLabel lblNewLabel_4 = new JLabel("");
					panel.add(lblNewLabel_4);
				}
				{
					JPanel panel_1 = new JPanel();
					panel.add(panel_1);
					panel_1.setLayout(new GridLayout(1, 0, 0, 0));
					{
						JLabel lblNewLabel_2 = new JLabel("Valuation Type");
						panel_1.add(lblNewLabel_2);
					}
					{
						JLabel comboBox = new JLabel();
						comboBox.setText("Mapping");
						panel_1.add(comboBox);
					}
				}
				{
					JPanel panel_1 = new JPanel();
					panel.add(panel_1);
					panel_1.setLayout(new GridLayout(1, 0, 0, 0));
					{
						JLabel lblNewLabel_3 = new JLabel("Weight");
						panel_1.add(lblNewLabel_3);
					}
				}
				textField_1.addChangeListener(new ChangeListener() {
	
					@Override
					public void stateChanged(ChangeEvent e) {
						lut.residents = (double) textField_1.getValue();
					}
				});
			}

		}

			JPanel panel_1 = new JPanel();
			contentPanel.add(panel_1,BorderLayout.CENTER);
			
			panel = new Panelscrollable();
			panel.setLayout(new GridLayout(0, 1, 0, 0));

		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						control_and_set();
						thiswindow.dispose();
						parent.namelabel.setText(lut.getName());
						
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton delete_button = new JButton("Delete");
				delete_button.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						parent.parent.panel.remove(parent);
						parent.parent.panel.updateUI();;
						thiswindow.dispose();
					}
				});
				buttonPane.add(delete_button);
			}

		}
		for(Valuation val: lut.valuations){
			panel.add(new Val_panel(val,thiswindow));
		}
		panel_1.setLayout(new BorderLayout(0, 0));
		JButton new_lut_button = new JButton("New");
		panel_1.add(new_lut_button, BorderLayout.SOUTH);
		new_lut_button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Val_panel newpanel = new Val_panel(new Valuation(0, Valuation_Types.constant, Mapping.constant, 0, 1), thiswindow);
				panel.add(newpanel);
				parent.lut.valuations.add(newpanel.valuation);
				panel.updateUI();
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		panel_1.add(scrollPane);
		scrollPane.setVerticalScrollBarPolicy(
				   JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); 
		scrollPane.setHorizontalScrollBarPolicy(
				   JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); 
		scrollPane.setViewportView(panel);
	}

	
	private boolean control_and_set(){
		double residents;
		try{
			residents = (double) textField_1.getValue();
		}
		catch(NumberFormatException e){
			return false;
		}
		lut.setName(textField.getText());
		lut.residents = residents;
		return true;
			
	}
}
