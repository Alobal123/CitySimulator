package krabec.citysimulator;

public class Triangle {

	Street s1;
	Street s2;
	Street s3;
	
	public Triangle(){}
	
	public Triangle(Street s1,Street s2, Street s3){
		this.s1 = s1;
		this.s2 = s2;
		this.s3 = s3;
	}
}